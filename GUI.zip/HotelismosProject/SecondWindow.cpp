#include "SecondWindow.h"
//using namespace System;
//using namespace System::Windows::Forms;
//[STAThreadAttribute]

// main(array<String^>^ args) {
//	Application::SetCompatibleTextRenderingDefault(false);
//	Application::EnableVisualStyles();
//	HotelismosProject::secondwindow frm;
//	Application::Run(% frm);
//}

/// <summary>
/// Required method for Designer support - do not modify
/// the contents of this method with the code editor.
/// </summary>

