#pragma once

namespace HotelismosProject {

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    /// <summary>
    /// Summary for secondwindow
    /// </summary>
    public ref class Secondwindow : public System::Windows::Forms::Form
    {
    public:
        Secondwindow(void)
        {
            InitializeComponent();
        }

    protected:
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        ~Secondwindow()
        {
            if (components)
            {
                delete components;
            }
        }

    private: System::Windows::Forms::Label^ label1;
    private: System::Windows::Forms::Button^ submit;

    private: System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
           /// <summary>
           /// Required method for Designer support - do not modify
           /// the contents of this method with the code editor.
           /// </summary>
           void InitializeComponent(void)
           {
               System::Windows::Forms::TextBox^ IDmanager;
               this->label1 = (gcnew System::Windows::Forms::Label());
               this->submit = (gcnew System::Windows::Forms::Button());
               IDmanager = (gcnew System::Windows::Forms::TextBox());
               this->SuspendLayout();
               // 
               // IDmanager
               // 
               this->IDmanager = (gcnew System::Windows::Forms::TextBox());
               // Rest of the code...

               // Set the properties for the IDmanager textbox
               this->IDmanager->Location = System::Drawing::Point(12, 12);
               this->IDmanager->Name = L"IDmanager";
               this->IDmanager->Size = System::Drawing::Size(100, 20);
               this->IDmanager->TabIndex = 0;

               // Add the IDmanager textbox to the form
               this->Controls->Add(this->IDmanager);

               // Find the textbox control with the name "IDmanager"
               for each (Control ^ control in this->Controls) {
                   if (control->Name == "IDmanager") {
                       IDmanager = dynamic_cast<TextBox^>(control);
                       break;
                   }
               }
               // 
               // label1
               // 
               this->label1->AutoSize = true;
               this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
                   static_cast<System::Byte>(0)));
               this->label1->Location = System::Drawing::Point(37, 99);
               this->label1->Name = L"label1";
               this->label1->Size = System::Drawing::Size(131, 25);
               this->label1->TabIndex = 0;
               this->label1->Text = L"Enter your ID:";
               // 
               // submit
               // 
               this->submit->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
                   static_cast<System::Byte>(0)));
               this->submit->Location = System::Drawing::Point(102, 147);
               this->submit->Name = L"submit";
               this->submit->Size = System::Drawing::Size(81, 32);
               this->submit->TabIndex = 1;
               this->submit->Text = L"submit";
               this->submit->UseVisualStyleBackColor = true;
               this->submit->Click += gcnew System::EventHandler(this, &Secondwindow::submit_Click);
               // 
               // Secondwindow
               // 
               this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
               this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
               this->ClientSize = System::Drawing::Size(430, 252);
               this->Controls->Add(IDmanager);
               this->Controls->Add(this->submit);
               this->Controls->Add(this->label1);
               this->Name = L"Secondwindow";
               this->Text = L"secondwindow";
               this->ResumeLayout(false);
               this->PerformLayout();

           }
#pragma endregion

    private: System::Void submit_Click(System::Object^ sender, System::EventArgs^ e) {
        // Get the text entered by the user in the textbox
        String^ userInput = IDmanager->Text;
            // Use the user input in your if condition or other logic
            if (userInput == "some value") {
                // Do something
            }
            else {
                // Do something else
            }

        // Close the current window
        this->Close();

        // Close the main window (MyForm)
        for each (Form ^ form in Application::OpenForms) {
            if (form->Name == "MyForm") {
                form->Close();
                break;
            }
        }

    };
}
