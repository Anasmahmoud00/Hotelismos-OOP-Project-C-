#pragma once
#include "SecondWindow.h"

namespace HotelismosProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ Manager;
	private: System::Windows::Forms::Button^ Guest;
	private: System::Windows::Forms::Button^ Staff;
	protected:



	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->Manager = (gcnew System::Windows::Forms::Button());
			this->Guest = (gcnew System::Windows::Forms::Button());
			this->Staff = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// Manager
			// 
			this->Manager->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->Manager->Location = System::Drawing::Point(328, 168);
			this->Manager->Name = L"Manager";
			this->Manager->Size = System::Drawing::Size(94, 44);
			this->Manager->TabIndex = 0;
			this->Manager->Text = L"Manager";
			this->Manager->UseVisualStyleBackColor = false;
			this->Manager->Click += gcnew System::EventHandler(this, &MyForm::Manager_Click);

			// Guest

			this->Guest->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->Guest->Location = System::Drawing::Point(202, 168);
			this->Guest->Name = L"Guest";
			this->Guest->Size = System::Drawing::Size(91, 44);
			this->Guest->TabIndex = 1;
			this->Guest->Text = L"Guest";
			this->Guest->UseVisualStyleBackColor = false;

			// Staff

			this->Staff->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->Staff->Location = System::Drawing::Point(78, 168);
			this->Staff->Name = L"Staff";
			this->Staff->Size = System::Drawing::Size(96, 44);
			this->Staff->TabIndex = 2;
			this->Staff->Text = L"Staff";
			this->Staff->UseVisualStyleBackColor = false;

			// label1

			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::SystemColors::Control;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft JhengHei", 12, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(150, 18);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(207, 21);
			this->label1->TabIndex = 3;
			this->label1->Text = L"\"Welcome to Hotelismos\"";
			this->label1->Click += gcnew System::EventHandler(this, &MyForm::label1_Click);

			// label2

			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(151, 113);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(195, 16);
			this->label2->TabIndex = 4;
			this->label2->Text = L"Choose the mood that you want:";
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::Control;
			this->ClientSize = System::Drawing::Size(501, 317);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->Staff);
			this->Controls->Add(this->Guest);
			this->Controls->Add(this->Manager);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Manager_Click(System::Object^ sender, System::EventArgs^ e) {
		Secondwindow^ window = gcnew Secondwindow();
		window->Show();
		this->Hide();
	}

	private: System::Void label1_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void MyForm_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	};
}