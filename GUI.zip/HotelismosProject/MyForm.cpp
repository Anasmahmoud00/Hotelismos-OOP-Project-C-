#include "MyForm.h"
#include "SecondWindow.h"
using namespace System;
using namespace System::Windows::Forms;
[STAThreadAttribute]

int main(array<String^>^ args) {
	Application::SetCompatibleTextRenderingDefault(false);
	Application::EnableVisualStyles();
	HotelismosProject::MyForm frm;
	Application::Run(% frm);
}